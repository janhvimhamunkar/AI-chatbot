# 🤖 Role-Based Prompt Engineering Chatbot

A Streamlit-based chatbot application where the **assistant’s behavior dynamically changes based on assigned roles** (e.g., Teacher, Lawyer, Developer).  
The project demonstrates **role-based prompt engineering** using the **Mistral AI API** with a clean, extensible architecture.

---

## Features

- **Role-Based Behavior**
  - Teacher: Step-by-step explanations with examples
  - Lawyer: Formal, cautious, and structured responses
  - Developer: Concise, technical, code-focused answers

- **System Prompt Conditioning**
  - Uses role-specific system prompts for precise behavior control

- **Mistral AI Integration**
  - Uses the latest Mistral Python SDK
  - OpenAI-compatible message schema

- **Interactive UI**
  - Built with Streamlit
  - Simple and responsive interface

- **Extensible Design**
  - Easy to add new roles
  - Ready for future features like memory, streaming, or multi-provider fallback

---

## Project Structure
```text
Role-Based-Chatbot/
│
├── app.py # Streamlit UI entry point
├── llm_client.py # Mistral API client abstraction
├── prompt_builder.py # Role-based message
├── roles.py # Role definitions and system prompts
├── config.py # Configuration and model settings
├── requirements.txt # Python dependencies
├── README.md # Project documentation
└── .streamlit/
            └── secrets.toml # API keys (not committed)
```


---

## Getting Started

### 1️. Clone the Repository

```text
git clone https://github.com/your-username/role-based-chatbot.git
cd Role-Based-Chatbot
```
### 2. Create and Activate a Virtual Environment (Recommended)
Windows
```text
python -m venv venv
venv\Scripts\activate
```
macOS / Linux
```text
python -m venv venv
source venv/bin/activate
```
### 2. Install Dependencies
```text
pip install -r requirements.txt
```
### 4. Configure Mistral API Key
Create the following file:

```text
.streamlit/secrets.toml
Add your API key:

toml
MISTRAL_API_KEY = "your_mistral_api_key_here"
```
 Never commit this file to version control.

### 5. Run the Application
```text
streamlit run app.py
Open your browser at:

http://localhost:8501
```
## How It Works
- The user selects a role (Teacher, Lawyer, Developer)

- A role-specific system prompt is injected

- User input is sent as a structured message

- Mistral generates a response aligned with the selected role

- The response is displayed in the Streamlit UI

## Adding a New Role
To add a new role, edit roles.py:
```text
"Scientist": {
    "description": "Explains concepts scientifically with logical reasoning.",
    "system_prompt": (
        "You are a scientist. Explain concepts using scientific reasoning, "
        "evidence, and clear terminology."
    ),
},
```
The role will automatically appear in the UI.

## Technologies Used
- Python 3.10+

- Streamlit

- Mistral AI Python SDK

- Prompt Engineering (System + User messages)

