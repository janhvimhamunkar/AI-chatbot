import streamlit as st

from roles import ROLES
from prompt_builder import build_messages
from llm_client import LLMClient

st.set_page_config(
    page_title="Role-Based Chatbot",
    page_icon="🤖",
    layout="centered",
)

st.title("Role-Based Prompt Engineering Chatbot")
role = st.selectbox(
    "Choose Assistant Role",
    options=list(ROLES.keys()),
    format_func=lambda r: f"{r} — {ROLES[r]['description']}",
)
debate_mode = st.checkbox("Enable Role Debate Mode")

user_input = st.text_area(
    "Your Question",
    placeholder="Type your question here...",
    height=120,
)
llm_client = LLMClient()

if not llm_client.is_configured():
    st.error(
        "Mistral API key not found.\n\n"
        "Add it to `.streamlit/secrets.toml`:\n\n"
        "MISTRAL_API_KEY = \"your_api_key_here\""
    )



if st.button("Generate Response"):
    if not user_input.strip():
        st.warning("Please enter a question.")
    else:
        with st.spinner("Thinking..."):
            try:
                if debate_mode:
                    st.subheader("Role Debate Mode Responses")

                    for debate_role in ROLES.keys():
                        messages = build_messages(debate_role, user_input, debate_mode=True)
                        response = llm_client.generate_response(messages)
                       
                        st.subheader("Assistant Response")
                        with st.expander(f"{debate_role} Response", expanded=True):
                            st.write(response)
                else:
                    messages = build_messages(role, user_input)
                    response = llm_client.generate_response(messages)
                    st.subheader(f"{role} Response")
                    st.write(response)
            except Exception as e:
                st.error(str(e))
