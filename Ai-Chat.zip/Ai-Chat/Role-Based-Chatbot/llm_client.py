from mistralai import Mistral
from config import MISTRAL_API_KEY, MODEL_NAME, GENERATION_CONFIG


class LLMClient:
    def __init__(self):
        import streamlit as st
        self.api_key = MISTRAL_API_KEY
        self.client = Mistral(api_key=self.api_key) if self.api_key else None

    def is_configured(self) -> bool:
        return bool(self.api_key)

    def generate_response(self, messages: list[dict]) -> str:
        if not self.client:
            raise RuntimeError("Mistral API key not configured")

        response = self.client.chat.complete(
            model=MODEL_NAME,
            messages=messages,
            temperature=GENERATION_CONFIG["temperature"],
            top_p=GENERATION_CONFIG["top_p"],
            max_tokens=GENERATION_CONFIG["max_tokens"],
        )

        return response.choices[0].message.content.strip()
