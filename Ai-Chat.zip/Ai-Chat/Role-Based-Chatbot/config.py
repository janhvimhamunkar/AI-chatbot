import os

MISTRAL_API_KEY = None

try:
    import streamlit as st
    MISTRAL_API_KEY = st.secrets.get("MISTRAL_API_KEY")
except Exception:
    pass

if not MISTRAL_API_KEY:
    MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")

MODEL_NAME = "mistral-small-latest"

GENERATION_CONFIG = {
    "temperature": 0.7,
    "top_p": 0.9,
    "max_tokens": 512,
}
