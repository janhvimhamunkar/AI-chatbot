from roles import ROLES


def build_messages(role: str, user_input: str, debate_mode: bool = False) -> list[dict]:
    if role not in ROLES:
        raise ValueError(f"Invalid role selected: {role}")
    system_prompt = ROLES[role]["system_prompt"]
    if debate_mode:
        other_roles = [r for r in ROLES.keys() if r != role]
        system_prompt += """
You are participating in a professional debate.

Instructions:
1. Present your viewpoint clearly from your role’s perspective.
2. Counter or critique one other role’s argument.
3. Keep the response structured and professional.

Format:
- Viewpoint
- Counterargument
"""
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_input},
    ]
